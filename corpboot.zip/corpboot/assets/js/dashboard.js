/*
Template Name: Corpboot - Dashboard
Description: Corporate HTML5 Template based on Bootstrap 5.
Version: 3.0
Author: Rafael Memmel - Wailo
Author URI: https://themeforest.net/user/wailothemes
*/

//---------------------------------------------------------------------------------------
//Dashboard Starter
//---------------------------------------------------------------------------------------
let tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
    window.addEventListener('DOMContentLoaded', event => {
    // Toggle the side navigation
    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
        // Uncomment Below to persist sidebar toggle between refreshes
        // if (localStorage.getItem('sb|sidebar-toggle') === 'true') {
        //     document.body.classList.toggle('sb-sidenav-toggled');
        // }
        sidebarToggle.addEventListener('click', event => {
            event.preventDefault();
            document.body.classList.toggle('sb-sidenav-toggled');
            localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
        });
    }
});
//---------------------------------------------------------------------------------------
//Charts
//---------------------------------------------------------------------------------------
//line_chart
const ctx = document.getElementById("line_chart").getContext('2d');
const myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["Sunday", "Monday", "Tuesday",
        "Wednesday", "Thursday", "Friday", "Saturday"],
        datasets: [{
            label: 'Last week',
            backgroundColor: 'rgba(30, 139, 195, 1)',
            borderColor: 'rgb(47, 128, 237)',
            data: [3000, 4000, 2000, 5000, 8000, 9000, 2000],
        }]
    },
    options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
    },
});
//bar_chart
const ctx_2 = document.getElementById("bar_chart").getContext('2d');
const myChart_2 = new Chart(ctx_2, {
    type: 'bar',
    data: {
        labels: ["HTML", "CSS", "JavaScript", "React", "Node.html", "Next.html", "Vue.js"],
        datasets: [{
            label: 'Web Technologies',
            backgroundColor: 'rgba(30, 139, 195, 1)',
            borderColor: 'rgb(47, 128, 237)',
            data: [300, 400, 200, 500, 800, 900, 200],
        }]
    },
    options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
    },
});
//pie_chart
// const ctx_3 = document.getElementById("pie_chart").getContext('2d');
// const myChart_3 = new Chart(ctx_3, {
//     type: 'pie',
//     data: {
//         labels: ["html", "css", "javascript", "php"],
//         datasets: [{
//             label: 'Technologies',
//             backgroundColor: 'rgba(161, 198, 247, 1)',
//             borderColor: 'rgb(47, 128, 237)',
//             data: [30, 40, 20, 50],
//         }]
//     },
// });
// //doughnut_chart
// const ctx_4 = document.getElementById("doughnut_chart").getContext('2d');
// const myChart_4 = new Chart(ctx_4, {
//     type: 'doughnut',
//     data: {
//         labels: ["rice", "yam", "tomato", "potato", "beans",
//         "maize", "oil"],
//         datasets: [{
//         label: 'food Items',
//         data: [30, 40, 20, 50, 80, 90, 20],
//         backgroundColor: ["#0074D9", "#FF4136", "#2ECC40",
//             "#FF851B", "#7FDBFF", "#B10DC9", "#FFDC00",
//             "#001f3f", "#39CCCC", "#01FF70", "#85144b",
//             "#F012BE", "#3D9970", "#111111", "#AAAAAA"]
//         }]
//     },
// });
