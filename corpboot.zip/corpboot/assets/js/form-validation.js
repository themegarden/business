function validate(el, alertForm) {
	// Get all of the required input fields
	const inputs = el.querySelectorAll('.required');

	// Get the first invalid input field, if any
	let first = null;

	// Iterate over all of the required input fields and validate them
	inputs.forEach(input => {
		// Remove all existing event listeners for the keyup, change, and blur events
		input.removeEventListener('keyup.validate', () => {});
		input.removeEventListener('change.validate', () => {});
		input.removeEventListener('blur.validate', () => {});

		// Add new event listeners for the keyup, change, and blur events
		input.addEventListener('keyup.validate', function() {
			if (input.value === '') {
				input.closest('div').closest('div').classList.add('has-error');
			} else {
				input.closest('div').classList.remove('has-error');
				fadeOut(el, 0.5);
			}
		});

		input.addEventListener('change.validate', function() {
			if (input.value === '') {
				input.closest('div').closest('div').classList.add('has-error');
			} else {
				input.closest('div').classList.remove('has-error');
				fadeOut(el, 0.5);
			}
		});

		input.addEventListener('blur.validate', function() {
			if (input.value === '') {
				input.closest('div').closest('div').classList.add('has-error');
			} else {
				input.closest('div').classList.remove('has-error');
				fadeOut(el, 0.5);
			}
		});

		// Validate the input field on load
		if (input.value === '') {
			input.closest('div').classList.add('has-error');
			if (first === null) {
				first = input;
				alertForm.innerHTML = `${input.dataset.name} Field Should Not Be Empty!`;
				fadeIn(el, 0.5);
			}
		} else if (input.classList.contains('required-email')) {
			const emailRegex = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
			if (!input.value.match(emailRegex)) {
				input.closest('div').classList.add('has-error');
				if (first === null) {
					first = input;
					alertForm.innerHTML = `${input.dataset.name} Is Not A Valid Email!`;
					fadeIn(el, 0.5);
				}
			}
		} else {
			input.closest('div').classList.remove('has-error');
		}
	});

	// If a validation error occurred, focus on the first invalid input field and return false
	if (first !== null) {
		first.focus();
		return false;
	} else {
		// Otherwise, fade out the alert form and return true
		fadeOut(el, 0.5);
		return true;
	}
}
